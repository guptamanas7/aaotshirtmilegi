"""
Main execution script for WFM Pipeline
Orchestrates the entire data processing workflow
"""

import pandas as pd
import logging
from datetime import datetime
from pathlib import Path

from config import INPUT_FILES, OUTPUT_FILES, FILTERS, TIMESHEET_SETTINGS, PRESERVE_COLUMNS
from utils.io_helpers import load_data, save_data, validate_input_files, combine_monthly_timesheets, load_existing_data, clean_dataframe_columns
from utils.preprocessors import preprocess_roster
from utils.mappers import map_employee_data, map_skills_data, map_attainment_data, map_preserved_data, update_status_from_exclusion
from utils.calculators import calculate_bench_metrics, calculate_billing_metrics, calculate_assignment_metrics, calculate_missing_bench_hours, calculate_last_billed_project
from utils.aggregator import aggregate_final_report

#supress warnings from pandas
pd.set_option('future.no_silent_downcasting', True)
# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('wfm_pipeline.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def main():
    """Main execution function for the WFM Pipeline"""
    
    logger.info("Starting WFM Pipeline execution...")
    start_time = datetime.now()
    
    try:
        # Step 0: Combine monthly timesheet files
        logger.info("Step 0: Combining monthly timesheet files...")
        try:
            df_combined_timesheet = combine_monthly_timesheets(
                monthly_folder_path=TIMESHEET_SETTINGS['monthly_folder'],
                output_path=TIMESHEET_SETTINGS['combined_output'],
                force_recreate=TIMESHEET_SETTINGS['force_recreate']
            )
            logger.info(f"Combined timesheet created with {len(df_combined_timesheet)} records")
        except Exception as e:
            logger.error(f"❌ Failed to combine monthly timesheets: {str(e)}")

            fallback_path = Path(INPUT_FILES['timesheet'])
            if fallback_path.exists():
                logger.warning(f"⚠️ Using existing file as fallback: {fallback_path}")
                df_combined_timesheet = pd.read_csv(fallback_path, index_col=None)
            else:
                logger.critical("🚫 No fallback timesheet available. Exiting...")
                return False

        
        # Step 1: Validate input files
        logger.info("Step 1: Validating input files...")
        if not validate_input_files(INPUT_FILES):
            logger.error("Input file validation failed. Exiting...")
            return False
        
        # Step 2: Load all data
        logger.info("Step 2: Loading data files...")
        data = {}
        for key, filepath in INPUT_FILES.items():
            try:
                data[key] = load_data(filepath)
                logger.info(f"Loaded {key}: {len(data[key])} records")
            except Exception as e:
                logger.error(f"Failed to load {key}: {str(e)}")
                return False
        
        # Step 3: Preprocess data
        logger.info("Step 3: Preprocessing data...")
        
        # Preprocess roster data
        df_roster = preprocess_roster(data['roster'], FILTERS)
        logger.info(f"Filtered roster: {len(df_roster)} records")
        
        # Initialize template with roster data
        df_template = data['template'].copy()
        
        # Step 4: Load existing data to preserve
        logger.info("Step 4: Loading existing data to preserve...")
        df_preserved = load_existing_data(OUTPUT_FILES['final_report'], PRESERVE_COLUMNS)
        
        # Step 5: Map employee data
        logger.info("Step 5: Mapping employee data...")
        df_template = map_employee_data(df_template, df_roster, data['employee'])
        
        # Step 6: Map skills data
        logger.info("Step 6: Mapping skills data...")
        df_template = map_skills_data(df_template, data['skills'])
        
        # Step 7: Map attainment data
        logger.info("Step 7: Mapping attainment data...")
        df_template = map_attainment_data(df_template, data['attainment'])

        # Step 8: Map preserved data
        logger.info("Step 8: Mapping preserved data...")
        df_template = map_preserved_data(df_template, df_preserved)

        # Step 9: Calculate bench missing metrics
        logger.info("Step 9: Calculating bench missing metrics...")
        df_template = calculate_missing_bench_hours(df_template, data['ytd_missing'])
        
        # Step 10: Calculate billing metrics (must be done before bench metrics for % calculation)
        logger.info("Step 10: Calculating billing metrics...")
        df_template = calculate_billing_metrics(df_template, data['timesheet'])
        
        # Step 11: Calculate bench metrics (includes bench % calculation)
        logger.info("Step 11: Calculating bench metrics...")
        df_template = calculate_bench_metrics(df_template, data['timesheet'])
        
        # Step 12: Calculate assignment metrics
        logger.info("Step 12: Calculating assignment metrics...")
        df_template = calculate_assignment_metrics(df_template, data['assignment'])

        # Step 13:  Calculating Last Billable Project
        logger.info("Step 13: Calculating Last Billable Project...")
        df_template = calculate_last_billed_project(df_template, data['timesheet'])

        # Step 14: Update status from exclusion list
        logger.info("Step 14: Updating status from exclusion list...")
        df_template = update_status_from_exclusion(df_template, data['exclusion'])
                
        # Step 15: Aggregate final report
        logger.info("Step 15: Aggregating final report...")
        df_final = aggregate_final_report(df_template)
        
        # Step 16: Clean DataFrame to remove any extra columns
        logger.info("Step 16: Cleaning DataFrame...")
        df_final = clean_dataframe_columns(df_final)
        
        # Step 17: Save final report
        logger.info("Step 17: Saving final report...")
        save_data(df_final, OUTPUT_FILES['final_report'])
        
        # Calculate execution time
        end_time = datetime.now()
        execution_time = (end_time - start_time).total_seconds()
        
        logger.info(f"Pipeline completed successfully!")
        logger.info(f"Final report saved to: {OUTPUT_FILES['final_report']}")
        logger.info(f"Total records processed: {len(df_final)}")
        logger.info(f"Total columns in final report: {len(df_final.columns)}")
        logger.info(f"Execution time: {execution_time: .2f} seconds")
        
        return True
        
    except Exception as e:
        logger.error(f"Pipeline execution failed: {str(e)}")
        return False

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)