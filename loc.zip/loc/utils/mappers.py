"""
Data mapping functions for WFM Pipeline
Handles mapping data between different sources
"""

import pandas as pd
import logging
from typing import Dict
from config import COLUMN_MAPPINGS, CONSTANTS
from .io_helpers import split_employee_column

logger = logging.getLogger(__name__)

def map_employee_data(df_template: pd.DataFrame, df_roster: pd.DataFrame, df_employee: pd.DataFrame) -> pd.DataFrame:
    """
    Map employee data from roster and employee files to template
    
    Args:
        df_template: Template DataFrame
        df_roster: Roster DataFrame
        df_employee: Employee DataFrame
        
    Returns:
        DataFrame: Template with mapped employee data
    """
    df = df_template.copy()
    
    # Map roster data to template
    roster_mappings = COLUMN_MAPPINGS['roster_to_template']
    
    df['Employee ID'] = df_roster['User/Employee ID']
    df['Name'] = df_roster['Name']
    df['Level'] = df_roster['Level  Name']
    df['Hire Date'] = df_roster['Employment Details Transfer/ Conversion Date']
    df['Country'] = df_roster['Geozone  Name']
    df['LOB'] = df_roster['Group Name']
    df['RO'] = df_roster['Reporting Org']
    df['Hiring source'] = df_roster['Hiring source']
    
    # Create mapping dictionaries from employee data
    employee_mappings = COLUMN_MAPPINGS['employee_mappings']
    
    id_to_location = dict(zip(df_employee['ID'], df_employee['Location']))
    df['Location'] = df['Employee ID'].map(id_to_location)
    
    id_to_group_lead = dict(zip(df_employee['ID'], df_employee['Group Lead']))
    df['Group Lead'] = df['Employee ID'].map(id_to_group_lead)
    
    id_to_supervisor = dict(zip(df_employee['ID'], df_employee['Supervisor']))
    df['Supervisor'] = df['Employee ID'].map(id_to_supervisor)
    
    logger.info("Employee data mapping completed")
    return df

def map_skills_data(df_template: pd.DataFrame, df_skills: pd.DataFrame) -> pd.DataFrame:
    """
    Map skills data to template
    
    Args:
        df_template: Template DataFrame
        df_skills: Skills DataFrame
        
    Returns:
        DataFrame: Template with mapped skills data
    """
    df = df_template.copy()
    
    # Create mapping dictionaries for each skill level
    skills_mappings = COLUMN_MAPPINGS['skills_mappings']
    
    id_to_basic = dict(zip(df_skills['Emp ID'], df_skills['1']))
    df['Basic'] = df['Employee ID'].map(id_to_basic)
    
    id_to_tertiary = dict(zip(df_skills['Emp ID'], df_skills['2']))
    df['Tertiary'] = df['Employee ID'].map(id_to_tertiary)
    
    id_to_secondary = dict(zip(df_skills['Emp ID'], df_skills['3']))
    df['Secondary'] = df['Employee ID'].map(id_to_secondary)
    
    id_to_primary = dict(zip(df_skills['Emp ID'], df_skills['4']))
    df['Primary'] = df['Employee ID'].map(id_to_primary)
    
    logger.info("Skills data mapping completed")
    return df

def map_attainment_data(df_template: pd.DataFrame, df_attainment: pd.DataFrame) -> pd.DataFrame:
    """
    Map YTD attainment data to template
    
    Args:
        df_template: Template DataFrame
        df_attainment: Attainment DataFrame
        
    Returns:
        DataFrame: Template with mapped attainment data
    """
    df = df_template.copy()
    
    # Split employee column in attainment data
    df_attainment_processed = split_employee_column(df_attainment, "Employee Name ID")
    
    # Create mapping dictionary
    id_to_ytd = dict(zip(df_attainment_processed['Employee ID'], df_attainment_processed['YTD_Attainment']))
    df['YTD Billing Attainment'] = df['Employee ID'].map(id_to_ytd)
    
    logger.info("Attainment data mapping completed")
    return df

def create_id_mapping(df: pd.DataFrame, id_col: str, value_col: str) -> Dict:
    """
    Create a mapping dictionary from ID to value
    
    Args:
        df: Source DataFrame
        id_col: Column name for IDs
        value_col: Column name for values
        
    Returns:
        Dict: Mapping dictionary
    """
    return dict(zip(df[id_col], df[value_col]))

def apply_mapping(df_target: pd.DataFrame, target_col: str, mapping_dict: Dict, id_col: str = 'Employee ID') -> pd.DataFrame:
    """
    Apply mapping dictionary to target DataFrame
    
    Args:
        df_target: Target DataFrame
        target_col: Column to populate
        mapping_dict: Mapping dictionary
        id_col: ID column in target DataFrame
        
    Returns:
        DataFrame: DataFrame with mapped values
    """
    df = df_target.copy()
    df[target_col] = df[id_col].map(mapping_dict)
    return df

def map_preserved_data(df_template: pd.DataFrame, df_preserved: pd.DataFrame, key_column: str = 'Employee ID') -> pd.DataFrame:
    """
    Map preserved columns from existing file to new template
    
    Args:
        df_template: Template DataFrame
        df_preserved: DataFrame with preserved columns
        key_column: Key column for mapping
        
    Returns:
        DataFrame: Template with mapped preserved data
    """
    if df_preserved is None:
        logger.info("No preserved data to map")
        return df_template
    
    df = df_template.copy()
    
    # Create mapping dictionaries for each preserved column
    preserve_columns = [col for col in df_preserved.columns if col != key_column]
    
    for col in preserve_columns:
        if col not in df.columns:
            # Add column if it doesn't exist in template
            df[col] = None
        
        # Create mapping and apply
        id_to_value = dict(zip(df_preserved[key_column], df_preserved[col]))
        df[col] = df[key_column].map(id_to_value).fillna(df[col])
    
    logger.info(f"Mapped preserved data for columns: {preserve_columns}")
    return df


def update_status_from_exclusion(df_template: pd.DataFrame, df_exclusion: pd.DataFrame) -> pd.DataFrame:
    """
    Update employee status based on exclusion list for specific leave types
    
    Args:
        df_template: Template DataFrame
        df_exclusion: Exclusion list DataFrame
        
    Returns:
        DataFrame: Template with updated status
    """
    df = df_template.copy()
    
    # Get leave types from config
    leave_types = CONSTANTS['exclusion_leave_types']
    
    # Filter exclusion data for specified leave types
    exclusion_filtered = df_exclusion[df_exclusion["timeType (Label)"].isin(leave_types)].copy()
    
    if exclusion_filtered.empty:
        logger.info("No exclusion records found for specified leave types")
        return df
    
    # Convert endDate to datetime
    exclusion_filtered["endDate"] = pd.to_datetime(exclusion_filtered["endDate"], dayfirst=True)
    
    # Ensure Status column exists and preserve blank/null values
    if 'Status' not in df.columns:
        df['Status'] = ''
    
    # Convert to string while preserving blanks (don't convert NaN to 'nan')
    df['Status'] = df['Status'].fillna('').astype(str)
    
    # Get today's date normalized (without time)
    today = pd.Timestamp.today().normalize()
    
    # Initialize counters for logging
    updated_count = 0
    
    # Iterate through exclusion records
    for idx, row in exclusion_filtered.iterrows():
        axtria_id = row["Axtria ID"]
        end_date = row["endDate"]
        status = row["timeType (Label)"]
        
        # Check if end date is valid and today's date is before or equal to end date
        if pd.notnull(end_date) and today <= end_date:
            # Find matching employees in template
            mask = df["Employee ID"] == axtria_id
            matching_employees = df[mask]
            
            if not matching_employees.empty:
                # Update status for matching employees
                df.loc[mask, "Status"] = status
                updated_count += len(matching_employees)
                logger.debug(f"Updated status for Employee ID {axtria_id} to '{status}' (end date: {end_date.strftime('%Y-%m-%d')})")
            else:
                logger.debug(f"Employee ID {axtria_id} not found in template")
        else:
            logger.debug(f"Skipping Employee ID {axtria_id} - end date {end_date} is in the past or invalid")
    
    logger.info(f"Updated status for {updated_count} employee records based on exclusion list")
    
    return df