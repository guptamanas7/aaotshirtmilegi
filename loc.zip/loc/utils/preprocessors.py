"""
Data preprocessing functions for WFM Pipeline
Handles filtering, cleaning, and transforming raw data
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, Any
from config import BENCH_PIDS

logger = logging.getLogger(__name__)

def preprocess_roster(df_roster: pd.DataFrame, filters: Dict[str, Any]) -> pd.DataFrame:
    """
    Preprocess roster data with filtering and name concatenation
    
    Args:
        df_roster: Raw roster DataFrame
        filters: Dictionary of filter criteria
        
    Returns:
        DataFrame: Preprocessed roster data
    """
    df = df_roster.copy()
    initial_count = len(df)
    
    # Apply filters
    if 'category_name' in filters:
        df = df[df['Category Name'] == filters['category_name']]
        logger.debug(f"After category filter: {len(df)} records")
    
    if 'sub_category_name' in filters:
        df = df[df['Sub Category Name'] == filters['sub_category_name']]
        logger.debug(f"After sub-category filter: {len(df)} records")
    
    # Optional: Filter on Regular/Temporary
    # if 'regular_temporary' in filters:
    #     df = df[df['Regular/Temporary'] == filters['regular_temporary']]
    #     logger.debug(f"After regular/temporary filter: {len(df)} records")
    
    # Concatenate name columns
    name_columns = ['First Name', 'Middle Name', 'Last Name']
    df['Name'] = (df[name_columns]
                  .fillna('')
                  .agg(' '.join, axis=1)
                  .str.replace(' +', ' ', regex=True)
                  .str.strip())
    
    logger.info(f"Roster preprocessing: {initial_count} -> {len(df)} records")
    return df

def preprocess_timesheet(df_timesheet: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess timesheet data with date parsing and level filtering
    
    Args:
        df_timesheet: Raw timesheet DataFrame
        
    Returns:
        DataFrame: Preprocessed timesheet data
    """
    df = df_timesheet.copy()
    initial_count = len(df)
    
    # Ensure Date is datetime
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Get ISO calendar week number
    iso_calendar = df['Date'].dt.isocalendar()
    df['ISO_Year'] = iso_calendar['year']
    df['ISO_Week'] = iso_calendar['week']
    
    # Convert Duration to numeric
    df['Duration (Decimal)'] = pd.to_numeric(df['Duration (Decimal)'], errors='coerce')
    
    # Extract level number and filter Level <= 9
    df['Level_Num'] = df['Level'].str.extract(r'(\d+)').astype('Int64')
    df = df[df['Level_Num'] <= 9]
    
    logger.info(f"Timesheet preprocessing: {initial_count} -> {len(df)} records")
    return df

def preprocess_assignment(df_assignment: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess assignment data with date parsing
    
    Args:
        df_assignment: Raw assignment DataFrame
        
    Returns:
        DataFrame: Preprocessed assignment data
    """
    df = df_assignment.copy()
    
    # Ensure Date is datetime
    df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)
    
    # Add Month-Year identifier
    df['Month-Year'] = df['Date'].dt.to_period('M')
    
    logger.info(f"Assignment preprocessing completed: {len(df)} records")
    return df

def filter_bench_pids(df: pd.DataFrame, include_bench: bool = True) -> pd.DataFrame:
    """
    Filter DataFrame based on bench PIDs
    
    Args:
        df: DataFrame with PID column
        include_bench: If True, include only bench PIDs; if False, exclude bench PIDs
        
    Returns:
        DataFrame: Filtered DataFrame
    """
    if include_bench:
        return df[df['PID'].isin(BENCH_PIDS)].copy()
    else:
        return df[~df['PID'].isin(BENCH_PIDS)].copy()

def add_time_periods(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add current, next, and next-to-next month periods to DataFrame
    
    Args:
        df: DataFrame with Month-Year column
        
    Returns:
        DataFrame: DataFrame with time period filters
    """
    df = df.copy()
    
    # Get current, next, and next-to-next months
    today = pd.Timestamp.today().to_period('M')
    df['Current_Month'] = today
    df['Next_Month'] = today + 1
    df['Next_To_Next_Month'] = today + 2
    
    return df