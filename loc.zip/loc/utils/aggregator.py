"""
Aggregation functions for WFM Pipeline
Handles final data aggregation and categorization
"""

import pandas as pd
import numpy as np
import logging
from config import CONSTANTS

logger = logging.getLogger(__name__)

def aggregate_final_report(df_template: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate final report with all calculations and categorizations
    
    Args:
        df_template: Template DataFrame with all mapped data
        
    Returns:
        DataFrame: Final aggregated report
    """
    df = df_template.copy()
    
    # Fill missing values with appropriate defaults
    numeric_columns = ['Billable', 'Non Billable', 'Bench', 'YTD HI Bench Count', 
                      'Current Month', 'Next Month', 'Next to Next Month', '%', 'Bench %']
    
    for col in numeric_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
    
    # Calculate billed category
    df = _calculate_billed_category(df)
    
    # Ensure all required columns are present
    df = _ensure_required_columns(df)
    
    # Clean and format data
    df = _clean_and_format_data(df)
    
    # Sort by employee ID
    if 'Employee ID' in df.columns:
        df = df.sort_values('Employee ID')
    
    logger.info(f"Final report aggregated: {len(df)} records")
    return df

def _calculate_billed_category(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate billed category based on utilization percentage
    
    Args:
        df: DataFrame with % column
        
    Returns:
        DataFrame: DataFrame with Billed Category column
    """
    df = df.copy()
    
    billing_config = CONSTANTS['billing_categories']
    bins = billing_config['bins']
    labels = billing_config['labels']
    
    df['Billed Category'] = pd.cut(df['%'], bins=bins, labels=labels, include_lowest=True)
    
    return df

def _ensure_required_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure all required columns are present in the final report
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame: DataFrame with all required columns
    """
    required_columns = [
        'Employee ID', 'Name', 'Level', 'Hire Date', 'Country', 'Location',
        'LOB', 'RO', 'Group Lead', 'Supervisor', 'Hiring source','Primary',
        'Secondary', 'Tertiary','Basic',  
        'YTD Billing Attainment','YTD Bench (Bench + Missing hrs)', 'YTD HI Bench Count',
        'Billable', 'Non Billable', 'Bench', 'Bench %',
        'Current Month', 'Next Month', 'Next to Next Month',
        'Project', '%', 'Billed Category','Last Billable Project Name','Last Billable Project Month','Status',
        'Available Date', 'SPOC', 'Project end date', 'Resource Block date',
        'Proposed Account', 'New Project Start date', 'Remarks','Old Comments'
    ]
    
    df_result = df.copy()
    
    # Add missing columns with default values
    for col in required_columns:
        if col not in df_result.columns:
            if col in ['Employee ID', 'Name', 'Level', 'Country', 'Location', 'LOB', 'RO', 
                      'Group Lead', 'Supervisor', 'Hiring source', 'Project', 'Billed Category']:
                df_result[col] = ''
            elif col == 'Hire Date':
                df_result[col] = pd.NaT
            else:
                df_result[col] = 0
            
            logger.warning(f"Added missing column '{col}' with default values")
    
    # Reorder columns
    df_result = df_result[required_columns]
    
    return df_result

def _clean_and_format_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean and format data for final output
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame: Cleaned and formatted DataFrame
    """
    df = df.copy()
    
    # Format percentage columns
    percentage_cols = ['%', 'Bench %']
    for col in percentage_cols:
        if col in df.columns:
            df[col] = df[col].round(2)
    
    # Format duration columns
    duration_cols = ['Billable', 'Non Billable', 'Bench', 'Current Month', 'Next Month', 'Next to Next Month']
    for col in duration_cols:
        if col in df.columns:
            df[col] = df[col].round(2)
    
    # Handle "NA" values in assignment columns
    assignment_cols = ['Current Month', 'Next Month', 'Next to Next Month']
    for col in assignment_cols:
        if col in df.columns:
            df[col] = df[col].replace(0, "NA")
    
    # Clean string columns
    string_cols = ['Name', 'Project', 'Group Lead', 'Supervisor']
    for col in string_cols:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()
            df[col] = df[col].replace('nan', '')
    
    # Handle skills columns
    skills_cols = ['Basic', 'Tertiary', 'Secondary', 'Primary']
    for col in skills_cols:
        if col in df.columns:
            df[col] = df[col].fillna('')
    
    return df

def calculate_summary_statistics(df: pd.DataFrame) -> dict:
    """
    Calculate summary statistics for the final report
    
    Args:
        df: Final report DataFrame
        
    Returns:
        dict: Summary statistics
    """
    stats = {}
    
    # Basic counts
    stats['total_employees'] = len(df)
    stats['employees_with_projects'] = len(df[df['Project'].notna() & (df['Project'] != '')])
    
    # Utilization statistics
    if '%' in df.columns:
        utilization = pd.to_numeric(df['%'], errors='coerce')
        stats['avg_utilization'] = utilization.mean()
        stats['median_utilization'] = utilization.median()
    
    # Bench statistics
    if 'Bench %' in df.columns:
        bench_pct = pd.to_numeric(df['Bench %'], errors='coerce')
        stats['avg_bench_percentage'] = bench_pct.mean()
        stats['high_bench_employees'] = len(df[bench_pct > 50])
    
    # Billing category distribution
    if 'Billed Category' in df.columns:
        category_counts = df['Billed Category'].value_counts()
        stats['billing_distribution'] = category_counts.to_dict()
    
    logger.info("Summary statistics calculated")
    return stats
