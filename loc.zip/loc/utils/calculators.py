import os
import re
import pandas as pd
import numpy as np
import logging
from typing import Tuple
from config import BENCH_PIDS, CONSTANTS, OUTPUT_FILES, MONTHLY_TIMESHEET_DIR
from .preprocessors import preprocess_timesheet, filter_bench_pids
from .io_helpers import save_data, split_employee_column
from datetime import datetime


logger = logging.getLogger(__name__)

def get_latest_month_year(folder_path: str) -> Tuple[int, int]:
    """Extract the latest month and year from timesheet filenames."""
    month_map = {
        'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4,
        'may': 5, 'jun': 6, 'jul': 7, 'aug': 8,
        'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
    }

    try:
        all_files = os.listdir(folder_path)
        csv_files = [f for f in all_files if f.endswith(".csv")]
    except Exception as e:
        raise FileNotFoundError(f"Error accessing folder: {e}")

    file_dates = []

    for file in csv_files:
        try:
            name = file.replace(".csv", "")
            parts = name.split("_")
            month_abbr = parts[0].lower()
            year = int(parts[1])
            month_num = month_map.get(month_abbr)
            if month_num is not None:
                file_dates.append((year, month_num))
        except Exception:
            continue

    if not file_dates:
        raise ValueError("No valid timesheet files found for date parsing.")

    file_dates.sort()
    latest_year, latest_month = file_dates[-1]
    return latest_year, latest_month

def calculate_bench_metrics(df_template: pd.DataFrame, df_timesheet: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate bench metrics including YTD high bench count and current month bench hours.
    Note: This function should be called AFTER calculate_billing_metrics to ensure
    Billable and Non Billable columns are available for percentage calculation.
    """
    df = df_template.copy()
    
    # Preprocess timesheet data
    df_ts = preprocess_timesheet(df_timesheet)
    
    # Filter for bench PIDs only
    df_bench = filter_bench_pids(df_ts, include_bench=True)
    
    # Calculate YTD High Bench Count
    df_summary = _calculate_ytd_high_bench(df_bench)
    
    # Map YTD high bench count to template
    df_summary_processed = split_employee_column(df_summary, "Employee")
    id_to_hibench = dict(zip(df_summary_processed['Employee ID'], df_summary_processed['YTD HI Bench Count']))
    df['YTD HI Bench Count'] = df['Employee ID'].map(id_to_hibench).fillna(0)
    
    # Calculate current month bench metrics
    df_current_bench = _calculate_current_month_bench(df_timesheet)
    df_current_bench_processed = split_employee_column(df_current_bench, "Employee")
    
    id_to_bench = dict(zip(df_current_bench_processed['Employee ID'], df_current_bench_processed['Total Bench Duration']))
    df['Bench'] = df['Employee ID'].map(id_to_bench).fillna(0)
    
    # Calculate bench percentage only if Billable and Non Billable columns exist
    if 'Billable' in df.columns and 'Non Billable' in df.columns:
        # Fill NaN values with 0 for calculation
        df['Billable'] = df['Billable'].fillna(0)
        df['Non Billable'] = df['Non Billable'].fillna(0)
        df['Bench'] = df['Bench'].fillna(0)
        
        # Calculate total hours (denominator)
        df['Total Hours'] = df['Billable'] + df['Non Billable'] + df['Bench']
        
        # Calculate bench percentage, avoiding division by zero
        df['Bench %'] = np.where(
            df['Total Hours'] > 0,
            ((df['Bench'] / df['Total Hours']) * 100).round(2),
            0
        )
        
        # Drop temporary column
        df.drop('Total Hours', axis=1, inplace=True)
        
        logger.info("Bench percentage calculated using formula: Bench / (Billable + Non Billable + Bench)")
    else:
        logger.warning("Billable and Non Billable columns not found. Bench % calculation skipped.")
        df['Bench %'] = 0
    
    logger.info("Bench metrics calculation completed")
    return df

def calculate_billing_metrics(df_template: pd.DataFrame, df_timesheet: pd.DataFrame) -> pd.DataFrame:
    """Calculate billing metrics for current month including billable and non-billable hours."""
    df = df_template.copy()
    
    # Filter for non-bench PIDs
    df_ts = df_timesheet.copy()
    df_non_bench = filter_bench_pids(df_ts, include_bench=False)
    
    # Filter for current month
    df_non_bench['Date'] = pd.to_datetime(df_non_bench['Date'])
    current_year, current_month = get_latest_month_year(MONTHLY_TIMESHEET_DIR)
    
    df_current_month = df_non_bench[
        (df_non_bench['Date'].dt.month == current_month) & 
        (df_non_bench['Date'].dt.year == current_year)
    ]
    
    # Calculate billable and non-billable durations
    result = df_current_month.groupby('Employee').agg(
        Billable_Duration=pd.NamedAgg(
            column='Duration (Decimal)', 
            aggfunc=lambda x: x[df_current_month.loc[x.index, 'Billability'] == 'Billable'].sum()
        ),
        Non_Billable_Duration=pd.NamedAgg(
            column='Duration (Decimal)', 
            aggfunc=lambda x: x[df_current_month.loc[x.index, 'Billability'] == 'Non Billable'].sum()
        )
    ).reset_index()
    
    # Map to template
    result_processed = split_employee_column(result, "Employee")
    
    id_to_billable = dict(zip(result_processed['Employee ID'], result_processed['Billable_Duration']))
    id_to_nonbillable = dict(zip(result_processed['Employee ID'], result_processed['Non_Billable_Duration']))
    
    df['Billable'] = df['Employee ID'].map(id_to_billable).fillna(0)
    df['Non Billable'] = df['Employee ID'].map(id_to_nonbillable).fillna(0)
    
    logger.info("Billing metrics calculation completed")
    return df

def calculate_assignment_metrics(df_template: pd.DataFrame, df_assignment: pd.DataFrame) -> pd.DataFrame:
    """Calculate assignment metrics including current, next, and next-to-next month durations."""
    df = df_template.copy()
    
    # Calculate duration metrics
    df_duration = _calculate_assignment_durations(df_assignment)
    
    # Map duration data
    id_to_current = dict(zip(df_duration['Employee ID'], df_duration['Current Month']))
    id_to_next = dict(zip(df_duration['Employee ID'], df_duration['Next Month']))
    id_to_next_to_next = dict(zip(df_duration['Employee ID'], df_duration['Next to Next Month']))
    
    df['Current Month'] = df['Employee ID'].map(id_to_current).fillna("NA")
    df['Next Month'] = df['Employee ID'].map(id_to_next).fillna("NA")
    df['Next to Next Month'] = df['Employee ID'].map(id_to_next_to_next).fillna("NA")
    
    # Calculate project assignments
    df_projects = _calculate_current_projects(df_assignment)
    id_to_project = dict(zip(df_projects['Employee ID'], df_projects['Project Name']))
    df['Project'] = df['Employee ID'].map(id_to_project).fillna("")
    
    # Calculate utilization percentage (handle "NA" values)
    df['Current Month Numeric'] = pd.to_numeric(df['Current Month'], errors='coerce')
    df['%'] = np.where(
        df['Current Month Numeric'].notna(),
        ((df['Current Month Numeric'] / CONSTANTS['standard_monthly_hours']) * 100).round(2),
        0
    )
    
    # Drop temporary column
    df.drop('Current Month Numeric', axis=1, inplace=True)
    
    logger.info("Assignment metrics calculation completed")
    return df

def calculate_missing_bench_hours(df_template: pd.DataFrame, df_missing: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate YTD missing bench hours from external CSV file and map to template.
    
    Args:
        df_template: Template DataFrame with Employee ID column
        df_missing: DataFrame containing missing bench hours data
    
    Returns:
        DataFrame with 'YTD Bench (Bench + Missing hrs)' column added
    """
    
    df = df_template.copy()
    
    # Ensure 'Net hours' is float
    df_missing["Net hours"] = pd.to_numeric(df_missing["Net hours"], errors='coerce')
        
    # Clean column strings
    df_missing["PID"] = df_missing["PID"].astype(str).str.strip()
    df_missing["Source for bench"] = df_missing["Source for bench"].astype(str).str.strip().str.lower()
    df_missing["Source of data"] = df_missing["Source of data"].astype(str).str.strip().str.lower()
        
    # Filter: PID (using bench PIDs from config)
    bench_pids = [
            "AXTR00342", "AXTR03571", "AXTR01586", "AXTR00423", "AXTR00726",
            "AXTR05664", "AXTR05550", "AXTR03524", "AXTR00327", "AXTR06205",
            "AXTR06206", "AXTR06204", "AXTR01423", "AXTR07302", "AXTR07307",
            "AXTR05056", "AXTR07306", "AXTR05055"
    ]
    filtered_df = df_missing[df_missing['PID'].isin(bench_pids)]
        
    # Bench filter dictionary: Source for bench → allowed Source of data
    bench_filter = {
        "bench": np.array(['not filled', 'mh', 'ts not filled', 'sys']),
        "cdp to bench": np.array(['cdp', 'cdp to bench']),
        "training to bench": np.array(['mt'])
    }
        
    # Apply mapping filter
    filtered_chunks = []
    for bench_type, valid_sources in bench_filter.items():
        temp_df = filtered_df[
            (filtered_df['Source for bench'] == bench_type) &
            (filtered_df['Source of data'].isin(valid_sources))
        ]
        filtered_chunks.append(temp_df)
        
    # Concatenate all filtered subsets
    final_filtered_df = pd.concat(filtered_chunks, ignore_index=True)
        
    # Group by Emp Id and sum Net hours
    result_df = final_filtered_df.groupby("Emp Id", as_index=False)["Net hours"].sum()
        
    # Round to 2 decimal places
    result_df["Net hours"] = result_df["Net hours"].round(2)
        
    # Map to template
    id_to_missing = dict(zip(result_df['Emp Id'], result_df['Net hours']))
    df['YTD Bench (Bench + Missing hrs)'] = df['Employee ID'].map(id_to_missing).fillna(0)
        
    logger.info(f"Missing bench hours calculation completed. Processed {len(result_df)} employees with missing hours.")

    return df

def _calculate_ytd_high_bench(df_bench: pd.DataFrame) -> pd.DataFrame:
    """Calculate YTD high bench count (weeks with >= 30 hours)."""
    # Load existing summary or create new one
    # df_summary = load_or_create_summary(OUTPUT_FILES['summary'])
    df_summary = pd.DataFrame()
    
    # Group by Employee and ISO_Week, sum Duration
    df_grouped_new = df_bench.groupby(['Employee', 'ISO_Week'], as_index=False)['Duration (Decimal)'].sum()
    
    # Map ISO_Week to column names (e.g., 'W14')
    def yearweek_to_col(iso_week):
        return 'W' + str(iso_week)
    
    df_grouped_new['WeekCol'] = df_grouped_new['ISO_Week'].apply(yearweek_to_col)
    
    # If summary is empty (first run), create it from new data
    if df_summary.empty:
        df_summary = df_grouped_new.pivot(index='Employee', columns='WeekCol', values='Duration (Decimal)').reset_index()
    else:
        # Convert existing summary to long format
        week_cols = [col for col in df_summary.columns if col.startswith('W')]
        df_summary_long = df_summary.melt(id_vars=['Employee'], value_vars=week_cols,
                                          var_name='WeekCol', value_name='Duration')
        
        # Merge existing and new data
        df_merged_long = pd.concat([
            df_summary_long,
            df_grouped_new[['Employee', 'WeekCol', 'Duration (Decimal)']].rename(columns={'Duration (Decimal)': 'Duration'})
        ], ignore_index=True)
        
        # Sum durations by Employee and WeekCol
        df_combined_long = df_merged_long.groupby(['Employee', 'WeekCol'], as_index=False)['Duration'].sum()
        
        # Pivot back to wide format
        df_summary = df_combined_long.pivot(index='Employee', columns='WeekCol', values='Duration').reset_index()
    
    # Fill NaNs with 0
    df_summary.fillna(0, inplace=True)
    
    # Get all week columns
    w_cols = [col for col in df_summary.columns if col.startswith('W')]
    
    # Calculate YTD high bench count (weeks with >= 30 hours)
    df_summary['YTD HI Bench Count'] = (df_summary[w_cols] >= CONSTANTS['high_bench_threshold']).sum(axis=1)
    
    # Order columns
    def week_sort_key(col):
        m = re.search(r'W(\d+)', col)
        return int(m.group(1)) if m else 0
    
    ordered_cols = ['Employee'] + sorted(w_cols, key=week_sort_key) + ['YTD HI Bench Count']
    df_summary = df_summary[ordered_cols]
    
    # Save updated summary
    save_data(df_summary, OUTPUT_FILES['summary'])
    
    return df_summary

def _calculate_current_month_bench(df_timesheet: pd.DataFrame) -> pd.DataFrame:
    """Calculate current month bench hours for each employee."""
    df_bench = df_timesheet[['Date', 'Employee', 'PID', 'Duration (Decimal)']].copy()
    df_bench['Date'] = pd.to_datetime(df_bench['Date'])
    
    # Filter for current month
    current_year, current_month = get_latest_month_year(MONTHLY_TIMESHEET_DIR)
    # current_year, current_month = datetime.now().year, datetime.now().month
    df_bench = df_bench[
        (df_bench['Date'].dt.month == current_month) &
        (df_bench['Date'].dt.year == current_year)
    ]
    
    # Filter for bench PIDs only
    df_bench_only = df_bench[df_bench['PID'].isin(BENCH_PIDS)]
    
    # Calculate total bench duration per employee
    bench_duration = (
        df_bench_only
        .groupby('Employee', as_index=False)['Duration (Decimal)']
        .sum()
        .rename(columns={'Duration (Decimal)': 'Total Bench Duration'})
    )
    
    # Get all unique employees from the timesheet
    all_employees = df_bench[['Employee']].drop_duplicates()
    
    # Merge with all employees to ensure everyone is included
    df_result = all_employees.merge(bench_duration, on='Employee', how='left')
    df_result['Total Bench Duration'] = df_result['Total Bench Duration'].fillna(0)
    
    return df_result

def _calculate_assignment_durations(df_assignment: pd.DataFrame) -> pd.DataFrame:
    """Calculate assignment durations for current, next, and next-to-next months."""
    df_dur = df_assignment[['Date', 'Employee', 'Duration (Decimal)']].copy()
    df_dur = split_employee_column(df_dur, "Employee")
    
    df_dur['Date'] = pd.to_datetime(df_dur['Date'], errors='coerce')
    df_dur = df_dur.dropna(subset=['Date'])
    df_dur['Month-Year'] = df_dur['Date'].dt.to_period('M')
    
    # Get current, next, and next-to-next months
    # year, month = get_latest_month_year(MONTHLY_TIMESHEET_DIR)
    year, month = datetime.now().year, datetime.now().month
    today = pd.Period(year=year, month=month, freq='M')
    next_months = [today, today+1, today + 2]
    
    # Filter for these months only
    df_filtered = df_dur[df_dur['Month-Year'].isin(next_months)]
    
    # Group by Employee ID and Month-Year
    df_grouped = (
        df_filtered
        .groupby(['Employee ID', 'Month-Year'])['Duration (Decimal)']
        .sum()
        .reset_index()
    )
    
    # Pivot and reindex columns
    df_pivot = df_grouped.pivot(index='Employee ID', columns='Month-Year', values='Duration (Decimal)')
    df_pivot = df_pivot.reindex(columns=next_months, fill_value= 0)
    
    # Rename columns
    column_mapping = dict(zip(next_months, ["Current Month", "Next Month", "Next to Next Month"]))
    df_pivot = df_pivot.rename(columns=column_mapping)
    
    return df_pivot.reset_index()

def _calculate_current_projects(df_assignment: pd.DataFrame) -> pd.DataFrame:
    """Calculate current projects for each employee."""
    df_proj = df_assignment[['Date', 'Employee', 'Project Name']].copy()
    df_proj = split_employee_column(df_proj, "Employee")
    
    df_proj['Date'] = pd.to_datetime(df_proj['Date'])
    df_proj['Month-Year'] = df_proj['Date'].dt.to_period('M')
    
    # Filter for current month
    year, month = get_latest_month_year(MONTHLY_TIMESHEET_DIR)
    today = pd.Period(year=year, month=month, freq='M')
    df_filtered = df_proj[df_proj['Month-Year'] == today]
    
    # Group projects by employee
    df_grouped = df_filtered.groupby(['Employee ID', 'Name'])['Project Name'].agg(', '.join).reset_index()
    
    return df_grouped


def calculate_last_billed_project(df_template: pd.DataFrame, df_timesheet: pd.DataFrame) -> pd.DataFrame:
    df = df_template.copy()

    # Initialize columns
    df['Last Billable Project Name'] = ''
    df['Last Billable Project Month'] = ''
    
    # Filter employees not assigned in next 3 months
    na_condition = (
        (df['Current Month'] == 'NA')&
        (df['Next Month'] == 'NA') &
        (df['Next to Next Month'] == 'NA')
    )
    
    if not na_condition.any():
        return df

    # Filter timesheet for billable records
    df_ts = df_timesheet[df_timesheet['Billability'].str.lower() == 'billable'].copy()
    df_ts = split_employee_column(df_ts, "Employee")
    df_ts['Date'] = pd.to_datetime(df_ts['Date'])
    df_ts = df_ts.sort_values(by='Date', ascending=False)
    
    # Get most recent billable project per employee
    df_last = df_ts.groupby('Employee ID').first().reset_index()
    
    # Create mapping dictionaries
    id_to_project_name = dict(zip(df_last['Employee ID'], df_last['Project Name']))
    id_to_project_month = dict(zip(df_last['Employee ID'], df_last['Date'].dt.to_period('M').astype(str)))
    
    # Update only filtered employees
    df.loc[na_condition, 'Last Billable Project Name'] = df.loc[na_condition, 'Employee ID'].map(id_to_project_name).fillna('')
    df.loc[na_condition, 'Last Billable Project Month'] = df.loc[na_condition, 'Employee ID'].map(id_to_project_month).fillna('')

    return df