import pandas as pd
import logging
from pathlib import Path
from typing import Dict, Union, Optional
import os
import re

logger = logging.getLogger(__name__)

def load_data(filepath: Union[str, Path]) -> pd.DataFrame:
    filepath = Path(filepath)
    
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    try:
        # FIXED: Always load CSV without index to avoid extra unnamed columns
        df = pd.read_csv(filepath, index_col=None, low_memory=False)
        logger.debug(f"Successfully loaded {len(df)} records from {filepath}")
        return df
    except Exception as e:
        logger.error(f"Error loading file {filepath}: {str(e)}")
        raise

def save_data(df: pd.DataFrame, filepath: Union[str, Path], index: bool = False) -> None:
    filepath = Path(filepath)
    
    try:
        # Create directory if it doesn't exist
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        # FIXED: Explicitly set index=False to prevent index column from being saved
        df.to_csv(filepath, index=False)
        logger.info(f"Successfully saved {len(df)} records to {filepath}")
    except Exception as e:
        logger.error(f"Error saving file {filepath}: {str(e)}")
        raise

def combine_monthly_timesheets(
    monthly_folder_path: Union[str, Path],
    output_path: Union[str, Path],
    force_recreate: bool = False
) -> pd.DataFrame:
    """
    Combine all monthly timesheet files (e.g., jan_2025.csv) into a single CSV file.

    Args:
        monthly_folder_path: Path to folder containing monthly timesheet files.
        output_path: Path where combined timesheet will be saved.
        force_recreate: If True, recreate combined file even if it exists.

    Returns:
        pd.DataFrame: Combined timesheet data.
    """
    monthly_folder_path = Path(monthly_folder_path)
    output_path = Path(output_path)

    logger.info(f"Combining monthly timesheet files from: {monthly_folder_path}")

    if not monthly_folder_path.exists():
        raise FileNotFoundError(f"Monthly timesheets folder not found: {monthly_folder_path}")


    try:
        # Get list of all .csv files in folder matching pattern like jan_2025.csv
        all_files = os.listdir(monthly_folder_path)
        ts_files = [f for f in all_files if re.match(r'^[a-z]{3}_\d{4}\.csv$', f.lower())]

        if not ts_files:
            raise ValueError(f"No timesheet files found in expected format (e.g., jan_2025.csv) in {monthly_folder_path}")

        logger.info(f"Found {len(ts_files)} timesheet files to combine:")
        for file in ts_files:
            logger.info(f"  - {file}")

        # Load and combine data
        df_list = []
        for file in ts_files:
            file_path = monthly_folder_path / file
            try:
                # FIXED: Load without index to avoid extra columns
                df = pd.read_csv(file_path, index_col=None)
                df['source_file'] = file
                df_list.append(df)
                logger.debug(f"Loaded {len(df)} records from {file}")
            except Exception as e:
                logger.warning(f"Failed to load {file}: {str(e)}")
                continue

        if not df_list:
            raise ValueError("No timesheet files could be loaded successfully")

        df_combined = pd.concat(df_list, ignore_index=True)
        logger.info(f"Successfully combined {len(df_list)} files into {len(df_combined)} total records")

        # FIXED: Save without index
        save_data(df_combined, output_path)
        logger.info(f"Combined timesheet saved to: {output_path}")

        return df_combined

    except Exception as e:
        logger.error(f"Error combining monthly timesheets: {str(e)}")
        raise

def validate_input_files(file_paths: Dict[str, Path]) -> bool:
    missing_files = []
    
    for name, path in file_paths.items():
        if not Path(path).exists():
            missing_files.append(f"{name}: {path}")
    
    if missing_files:
        logger.error("Missing input files:")
        for file in missing_files:
            logger.error(f"  - {file}")
        return False
    
    logger.info("All input files validated successfully")
    return True

def load_or_create_summary(summary_path: Union[str, Path]) -> pd.DataFrame:
    """
    Load existing summary file or create new empty DataFrame.
    This function is not in use in the current codebase, but it can be useful for future reference.
    """
    summary_path = Path(summary_path)
    
    try:
        # FIXED: Load without index to avoid extra columns
        df_summary = pd.read_csv(summary_path, index_col=None)
        logger.info(f"Existing summary data loaded from: {summary_path}")
        return df_summary
    except FileNotFoundError:
        logger.info("No existing summary file found. Creating new summary file.")
        return pd.DataFrame()
    except Exception as e:
        logger.warning(f"Error loading summary file: {str(e)}. Creating new summary file.")
        return pd.DataFrame()

def split_employee_column(df: pd.DataFrame, column_name: str) -> pd.DataFrame:
    """Split combined employee column into Employee ID and Name columns."""
    df = df.copy()
    
    # Apply regex to extract Employee ID and Name
    df['Employee ID'] = df[column_name].str.extract(r'\b(A\d{4})\b')
    df = df.dropna(subset=['Employee ID'])

    df['Name'] = df[column_name].str.replace(r'\bA\d{4}\b\s*', '', regex=True)
    df = df.drop(columns=[column_name])

    front_cols = ['Employee ID', 'Name']
    other_cols = [col for col in df.columns if col not in front_cols]

    # Reorder columns to have Employee ID and Name at the front
    df = df[front_cols + other_cols]
    return df

def load_existing_data(filepath: Union[str, Path], preserve_columns: list, key_column: str = 'Employee ID') -> Optional[pd.DataFrame]:
    """
    Load existing output file and extract columns to preserve
    
    Args:
        filepath: Path to existing output file
        preserve_columns: List of columns to preserve
        key_column: Key column for mapping (default: 'Employee ID')
    
    Returns:
        DataFrame with preserved columns or None if file doesn't exist
    """
    filepath = Path(filepath)
    
    if not filepath.exists():
        logger.info(f"No existing file found at {filepath}")
        return None
    
    try:
        # FIXED: Load without index to avoid extra columns
        df_existing = pd.read_csv(filepath, index_col=None)
        
        # Check which preserve columns actually exist in the file
        available_columns = [col for col in preserve_columns if col in df_existing.columns]
        
        if not available_columns:
            logger.warning("None of the preserve columns found in existing file")
            return None
        
        # Include key column for mapping
        columns_to_extract = [key_column] + available_columns
        columns_to_extract = [col for col in columns_to_extract if col in df_existing.columns]
        
        df_preserved = df_existing[columns_to_extract].copy()
        logger.info(f"Preserved {len(available_columns)} columns from existing file: {available_columns}")
        
        return df_preserved
        
    except Exception as e:
        logger.error(f"Error loading existing file {filepath}: {str(e)}")
        return None

def clean_dataframe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean DataFrame to remove any unnamed index columns that might have been accidentally included.
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame: Cleaned DataFrame without unnamed index columns
    """
    df_clean = df.copy()
    
    # Remove columns that are unnamed or look like index columns
    columns_to_drop = []
    for col in df_clean.columns:
        if (str(col).startswith('Unnamed:') or 
            str(col) == '' or 
            str(col) == 'index' or
            pd.isna(col)):
            columns_to_drop.append(col)
    
    if columns_to_drop:
        logger.info(f"Dropping unwanted columns: {columns_to_drop}")
        df_clean = df_clean.drop(columns=columns_to_drop)
    
    return df_clean