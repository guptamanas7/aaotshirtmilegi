# Demand Processing Pipeline

A production-ready Python pipeline for processing and combining demand data from multiple sources (pipeline and assignment data) to generate comprehensive demand forecasting reports.

Overview

This pipeline processes two main types of data:
1. **Pipeline Data**: Future opportunities from Excel files containing resource planning sheets
2. **Assignment Data**: Current resource assignments from CSV files

The output is a unified CSV file containing both pipeline and assignment demand data, formatted for downstream analysis and reporting.

## System Requirements

### Software Requirements
- Python 3.8 or higher
- Required Python packages (see `requirements.txt`)


### Data Requirements
- Write access to input and output directories
- Stable file structure for input Excel files
- Valid CSV format for input data

## Installation

1. **Clone or download the project files**
2. **Install required packages:**
   ```bash
   pip install -r requirements.txt
   ```

### Required Python Packages
```
pandas>=1.5.0
numpy>=1.21.0
openpyxl>=3.0.10
pathlib
```

## Project Structure

```
demand/
├── /
│   └── demand.py           # Main processing script
├── data/
│   ├── demand_columns.csv           # Template for output columns
│   ├── Pipeline.csv                 # Pipeline opportunities data
│   ├── assignment.csv               # Current assignments data
│   └── pricing_sheets/              # Excel files with resource plans
│       ├── OLI001_Project_A.xlsx
│       ├── OLI002_Project_B.xlsx
│       └── ...
├── output/
│   └── demand.csv                   # Final output file
├── README.md
└── requirements.txt
```

## Configuration

Update the `config_paths` dictionary in the `main()` function:

```python
config_paths = {
    'demand_columns_csv': '../data/demand_columns.csv',
    'pipeline_csv': '../data/Pipeline.csv',
    'assignment_csv': '../data/assignment.csv',
    'pricing_sheets_dir': '../data/pricing_sheets',
    'output_dir': '../output'
}
```

## Data Flow


### Basic Usage
```bash
python demand_processor.py
```

### Advanced Usage with Custom Configuration
```python
from demand_processor import DemandProcessor

# Custom configuration
config = {
    'demand_columns_csv': '/path/to/template.csv',
    'pipeline_csv': '/path/to/pipeline.csv',
    'assignment_csv': '/path/to/assignment.csv',
    'pricing_sheets_dir': '/path/to/excel_files',
    'output_dir': '/path/to/output'
}

# Initialize processor
processor = DemandProcessor(config, log_level='DEBUG')

# Run pipeline
success = processor.run_pipeline()

if success:
    print("Processing completed successfully!")
else:
    print("Processing failed - check logs for details")
```

## Process Documentation

### Step 1: Configuration Validation
- Validates all required files exist
- Checks directory permissions
- Verifies file formats are readable
- **Duration**: ~1-2 seconds
- **Expected Output**: Validation success message

### Step 2: Data Loading
- Loads template CSV (defines output structure)
- Loads pipeline CSV with opportunity data
- Loads assignment CSV with current allocations
- **Duration**: ~5-10 seconds depending on file size
- **Expected Output**: File loading confirmation with row counts

### Step 3: Pipeline Data Processing

#### 3.1 Excel File Processing
- Searches for Excel files matching OLI codes
- Processes two sheet types:
  - `Monthly Resource Plan` (3 months of data)
  - `Weekly Resource Plan` (weekly breakdowns)
- Extracts resource requirements by:
  - Designation
  - Level
  - Location
  - Time period

#### 3.2 Resource Calculation
- Sums hours from relevant columns
- Converts hours to resource count (hours ÷ 525)
- Applies ceiling function for whole resources
- Groups by project, level, and location

#### 3.3 Data Enrichment
- Merges with pipeline metadata
- Adds project details, timelines, and stakeholders
- Formats for final output structure

**Duration**: ~30 seconds to 5 minutes (depends on number of Excel files)

### Step 4: Assignment Data Processing

#### 4.1 Data Cleaning
- Filters out generic/system-generated employees
- Removes entries matching pattern: `A####_Generic`
- Cleans column names and formats

#### 4.2 Level Mapping
- Maps employee designations to standardized levels (L1-L10)
- Handles variations in naming conventions
- Flags unmapped designations as 'Sys Generated'

#### 4.3 Data Extraction
- Extracts customer information from combined fields
- Separates Project Manager IDs and names
- Processes project names and removes prefixes

#### 4.4 Aggregation
- Groups by project and level
- Sums resource duration
- Converts to resource count (duration ÷ 525)

**Duration**: ~10-30 seconds

### Step 5: Data Combination and Export
- Combines pipeline and assignment data
- Applies final data validation
- Formats dates and numeric fields
- Exports to CSV with timestamp
- **Duration**: ~5-10 seconds

### Step 6: Summary and Reporting
- Generates processing statistics
- Creates detailed log file
- Provides success/failure counts
- Reports any data quality issues

## Error Handling

The pipeline includes comprehensive error handling:

### Configuration Errors
- Missing required files
- Invalid file paths
- Permission issues
- **Action**: Pipeline stops with clear error message

### Data Processing Errors
- Corrupt Excel files
- Missing worksheet tabs
- Invalid data formats
- **Action**: Skips problematic files, logs error, continues processing

### Runtime Errors
- Memory issues with large files
- Network connectivity problems
- Disk space issues
- **Action**: Attempts recovery, logs detailed error information

## Monitoring and Logging

### Log Levels
- **DEBUG**: Detailed processing information
- **INFO**: Major step completion and statistics
- **WARNING**: Recoverable issues (missing files, format problems)
- **ERROR**: Critical failures requiring attention


### Key Metrics Tracked
- Number of pipeline files processed successfully
- Number of pipeline files that failed
- Assignment records processed
- Total output records generated
- Processing time for each step

### Example Log Output
```
2024-01-15 14:30:01 - DemandProcessor - INFO - Starting demand processing pipeline...
2024-01-15 14:30:01 - DemandProcessor - INFO - Configuration validation completed successfully
2024-01-15 14:30:02 - DemandProcessor - INFO - Loaded pipeline data: (150, 12)
2024-01-15 14:30:03 - DemandProcessor - INFO - Processing OLI code: OLI001
2024-01-15 14:30:04 - DemandProcessor - WARNING - Sheet 'Weekly Resource Plan' not found in /path/to/OLI001.xlsx
2024-01-15 14:30:05 - DemandProcessor - INFO - Pipeline processing completed. Output shape: (45, 20)
```

## Output Format

The final output file (`demand.csv`) contains the following columns:

| Column Name | Description | Data Type | Example |
|-------------|-------------|-----------|---------|
| Sold/Pipeline | Data source type | String | "Pipeline" or "Sold" |
| Type | Opportunity type | String | "New Business" |
| Client | Client name | String | "ABC Corporation" |
| Project | Project name | String | "Digital Transformation" |
| Sold PID/ Opp ID | Unique identifier | String | "OLI001" |
| Opp Probability | Success probability | Integer | 75 |
| LOB | Line of Business | String | "Technology" |
| Project Value | Project value with currency | String | "500000 USD" |
| Allocation Start Date | Start date | Date | "01/15/2024" |
| Allocation End Date | End date | Date | "12/31/2024" |
| Required from which Month | First month needed | String | "Jan'24" |
| No of resources required | Resource count | Integer | 3 |
| Level | Resource level | String | "L5" |
| Location | Work location | String | "New York" |
| Request Date | When request was made | Date | "01/15/2024" |
| Requested by | Requesting person | String | "John Smith" |




---

*This documentation is done by the Summer Interns of 25, Alok and Manas. Last updated: July 2025*