import os
import pandas as pd
import numpy as np
from datetime import datetime
import logging
from pathlib import Path
import sys
from typing import Dict, List, Tuple, Optional
from openpyxl import load_workbook
import warnings
warnings.filterwarnings('ignore')

class DemandProcessor:
    """Production-ready demand processing pipeline with comprehensive logging and error handling"""
    
    def __init__(self, config_paths: Dict[str, str], log_level: str = 'INFO'):
        """
        Initialize the demand processor
        
        Args:
            config_paths: Dictionary with paths for data files
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        """
        self.config_paths = config_paths
        self.setup_logging(log_level)
        self.validation_errors = []
        self.processing_stats = {
            'pipeline_files_processed': 0,
            'pipeline_files_failed': 0,
            'assignment_records_processed': 0,
            'total_records_output': 0
        }
        
        # Level mapping dictionary
        self.level_mapping = {
            'Principal': 'L10',
            'Senior Director': 'L9',
            'Sr Director': 'L9',
            'Sr. Director': 'L9',
            'Associate Director': 'L7',
            'Director': 'L8',
            'Senior Manager': 'L6',
            'Sr Manager': 'L6',
            'Sr. Manager': 'L6',
            'Manager': 'L5',
            'Project Leader': 'L4',
            'Project Lead': 'L4',
            'Senior Associate': 'L3',
            'Sr Associate': 'L3',
            'Sr. Associate': 'L3',
            'Associate': 'L2',
            'Analyst': 'L1'
        }
        
    def setup_logging(self, log_level: str):
        """Setup logging configuration"""
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        logging.basicConfig(
            level=getattr(logging, log_level.upper()),
            format=log_format,
            handlers=[
                # logging.FileHandler(f'demand_processing.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def validate_config(self) -> bool:
        """Validate configuration and required files"""
        self.logger.info("Starting configuration validation...")
        
        required_files = ['demand_columns_csv', 'pipeline_csv', 'assignment_csv']
        required_dirs = ['pricing_sheets_dir', 'output_dir']
        
        # Check required files exist
        for key in required_files:
            if key not in self.config_paths:
                self.logger.error(f"Missing configuration key: {key}")
                return False
            
            file_path = Path(self.config_paths[key])
            if not file_path.exists():
                self.logger.error(f"Required file not found: {file_path}")
                return False
                
        # Check required directories exist
        for key in required_dirs:
            if key not in self.config_paths:
                self.logger.error(f"Missing configuration key: {key}")
                return False
                
            dir_path = Path(self.config_paths[key])
            if not dir_path.exists():
                self.logger.error(f"Required directory not found: {dir_path}")
                return False
                
        self.logger.info("Configuration validation completed successfully")
        return True
        
    def load_data(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Load all required data files with validation"""
        self.logger.info("Loading data files...")
        
        try:
            # Load demand columns template
            df_template = pd.read_csv(self.config_paths['demand_columns_csv'])
            self.logger.info(f"Loaded demand columns template: {df_template.shape}")
            
            # Load pipeline data
            df_pipeline = pd.read_csv(self.config_paths['pipeline_csv'])
            df_pipeline.columns = df_pipeline.columns.str.strip()  # Clean column names
            self.logger.info(f"Loaded pipeline data: {df_pipeline.shape}")
            
            # Load assignment data
            df_assignment = pd.read_csv(self.config_paths['assignment_csv'])
            self.logger.info(f"Loaded assignment data: {df_assignment.shape}")
            
            return df_template, df_pipeline, df_assignment
            
        except Exception as e:
            self.logger.error(f"Error loading data files: {str(e)}")
            raise
            
    def process_pipeline_data(self, df_template: pd.DataFrame, df_pipeline: pd.DataFrame) -> pd.DataFrame:
        """Process pipeline data from Excel files"""
        self.logger.info("Starting pipeline data processing...")
        
        df_temp_pipe = df_template.copy()
        extracted_rows = []
        oli_first_month_source = {}
        sheets_to_read = ["Monthly Resource Plan", "Weekly Resource Plan"]
        
        for idx, row in df_pipeline.iterrows():
            oli_code = str(row['OLI Code'])
            self.logger.debug(f"Processing OLI code: {oli_code}")
            
            try:
                # Find matching file
                matched_file = self._find_matching_file(oli_code)
                if not matched_file:
                    # self.logger.warning(f"No matching file found for OLI code: {oli_code}")
                    self.processing_stats['pipeline_files_failed'] += 1
                    continue
                
                # Process the Excel file
                file_rows = self._process_excel_file(matched_file, oli_code, sheets_to_read, oli_first_month_source)
                extracted_rows.extend(file_rows)
                
                self.processing_stats['pipeline_files_processed'] += 1
                self.logger.debug(f"Successfully processed file for OLI code: {oli_code}")
                
            except Exception as e:
                self.logger.error(f"Error processing OLI code {oli_code}: {str(e)}")
                self.processing_stats['pipeline_files_failed'] += 1
                continue
        
        if not extracted_rows:
            self.logger.warning("No data extracted from pipeline processing")
            return pd.DataFrame()
            
        # Create and process extracted dataframe
        extracted_df = pd.DataFrame(extracted_rows)
        self.logger.info(f"Extracted {len(extracted_df)} rows from pipeline processing")
        
        # Group and aggregate data
        grouped_df_pipe = extracted_df.groupby(
            ['Sold PID/ Opp ID', 'Designation', 'Level', 'Loc', 'First Month Recorded'],
            as_index=False
        )['Total hours'].sum()
        
        # Convert hours to resource count (ceiling of hours/525)
        grouped_df_pipe['Total hours'] = np.ceil(grouped_df_pipe['Total hours'] / 525)
        
        # Merge with pipeline data to get additional information
        merged_df = self._merge_pipeline_data(grouped_df_pipe, df_pipeline)
        
        # Populate template with merged data
        df_temp_pipe = self._populate_pipeline_template(df_temp_pipe, merged_df)
        
        self.logger.info(f"Pipeline processing completed. Output shape: {df_temp_pipe.shape}")
        return df_temp_pipe
        
    def _find_matching_file(self, oli_code: str) -> Optional[str]:
        """Find matching Excel file for OLI code"""
        folder_path = Path(self.config_paths['pricing_sheets_dir'])
        
        for filename in os.listdir(folder_path):
            if filename.startswith(oli_code) and filename.endswith(".xlsx"):
                return str(folder_path / filename)
        return None
        
    def _process_excel_file(self, file_path: str, oli_code: str, sheets_to_read: List[str], 
                           oli_first_month_source: Dict) -> List[Dict]:
        """Process individual Excel file and extract data"""
        rows = []
        
        try:
            wb = load_workbook(file_path, data_only=True)
            
            for sheet_name in sheets_to_read:
                if sheet_name not in wb.sheetnames:
                    self.logger.warning(f"Sheet '{sheet_name}' not found in {file_path}")
                    continue
                    
                ws = wb[sheet_name]
                sheet_rows = self._extract_sheet_data(ws, sheet_name, oli_code, oli_first_month_source)
                rows.extend(sheet_rows)
                
        except Exception as e:
            self.logger.error(f"Error reading Excel file {file_path}: {str(e)}")
            raise
            
        return rows
        
    def _extract_sheet_data(self, ws, sheet_name: str, oli_code: str, 
                           oli_first_month_source: Dict) -> List[Dict]:
        """Extract data from a specific sheet"""
        rows = []
        
        # Determine column layout based on sheet type
        if sheet_name == "Monthly Resource Plan":
            month_cols, final_col, first_month_name = self._get_monthly_columns(ws, 7, oli_code, oli_first_month_source)
        elif sheet_name == "Weekly Resource Plan":
            month_cols, final_col, first_month_name = self._get_weekly_columns(ws, 6, oli_code, oli_first_month_source)
        else:
            return rows
            
        # Extract data from rows starting from row 8
        r = 8
        while True:
            try:
                designation = ws[f"B{r}"].value
                if designation is None or str(designation).strip() == "":
                    break
                    
                level = ws[f"C{r}"].value
                loc = ws[f"E{r}"].value
                
                # Calculate sum of hours
                sum_hours = self._calculate_sum_hours(ws, r, sheet_name, month_cols, final_col)
                
                rows.append({
                    'Sold PID/ Opp ID': oli_code,
                    'Designation': designation,
                    'Level': level,
                    'Loc': loc,
                    'Total hours': sum_hours,
                    'First Month Recorded': oli_first_month_source.get(oli_code, {}).get('first_month', 'Unknown')
                })
                
                r += 1
                
            except Exception as e:
                self.logger.warning(f"Error processing row {r} in sheet {sheet_name}: {str(e)}")
                break
                
        return rows
        
    def _get_monthly_columns(self, ws, month_row: int, oli_code: str, 
                           oli_first_month_source: Dict) -> Tuple[List[int], int, str]:
        """Get column information for Monthly Resource Plan"""
        month_cols = []
        first_month_name = None
        
        for col_idx in range(8, min(11, ws.max_column + 1)):  # H, I, J columns
            if len(month_cols) < 3:
                month_cols.append(col_idx)
                if oli_code not in oli_first_month_source and first_month_name is None:
                    cell_value = ws.cell(row=month_row, column=col_idx).value
                    if cell_value is not None:
                        if hasattr(cell_value, 'strftime'):
                            first_month_name = cell_value.strftime("%b'%y")
                        else:
                            first_month_name = str(cell_value).strip()
                        oli_first_month_source[oli_code] = {
                            'first_month': first_month_name,
                            'sheet_source': 'Monthly Resource Plan'
                        }
                        
        final_col = month_cols[-1] if month_cols else 8
        return month_cols, final_col, first_month_name
        
    def _get_weekly_columns(self, ws, month_row: int, oli_code: str, 
                          oli_first_month_source: Dict) -> Tuple[List[int], int, str]:
        """Get column information for Weekly Resource Plan"""
        months_seen = []
        first_month_col = 8
        final_col = 8
        
        # First pass: identify unique months
        for col_idx in range(8, ws.max_column + 1):
            cell_value = ws.cell(row=month_row, column=col_idx).value
            if cell_value is not None:
                if hasattr(cell_value, 'strftime'):
                    month_str = cell_value.strftime("%b'%y")
                else:
                    month_str = str(cell_value).strip()
                
                if month_str not in months_seen:
                    months_seen.append(month_str)
                    if oli_code not in oli_first_month_source:
                        oli_first_month_source[oli_code] = {
                            'first_month': month_str,
                            'sheet_source': 'Weekly Resource Plan'
                        }
                    if len(months_seen) == 3:
                        break
                        
        # Second pass: find last occurrence of 3rd month
        if len(months_seen) >= 3:
            third_month = months_seen[2]
            for col_idx in range(8, ws.max_column + 1):
                cell_value = ws.cell(row=month_row, column=col_idx).value
                if cell_value is not None:
                    if hasattr(cell_value, 'strftime'):
                        month_str = cell_value.strftime("%b'%y")
                    else:
                        month_str = str(cell_value).strip()
                    if month_str == third_month:
                        final_col = col_idx
                        
        return list(range(first_month_col, final_col + 1)), final_col, None
        
    def _calculate_sum_hours(self, ws, row: int, sheet_name: str, month_cols: List[int], 
                           final_col: int) -> float:
        """Calculate sum of hours for a specific row"""
        sum_hours = 0
        
        if sheet_name == "Monthly Resource Plan":
            for col_idx in month_cols:
                cell_value = ws.cell(row=row, column=col_idx).value
                if cell_value is not None:
                    try:
                        sum_hours += float(cell_value)
                    except (ValueError, TypeError):
                        continue
        elif sheet_name == "Weekly Resource Plan":
            for col_idx in range(8, final_col + 1):
                cell_value = ws.cell(row=row, column=col_idx).value
                if cell_value is not None:
                    try:
                        sum_hours += float(cell_value)
                    except (ValueError, TypeError):
                        continue
                        
        return sum_hours
        
    def _merge_pipeline_data(self, grouped_df: pd.DataFrame, df_pipeline: pd.DataFrame) -> pd.DataFrame:
        """Merge grouped pipeline data with original pipeline information"""
        try:
            merged_df = grouped_df.merge(
                df_pipeline,
                left_on='Sold PID/ Opp ID',
                right_on='OLI Code',
                how='left'
            )
            self.logger.info(f"Merged pipeline data successfully. Shape: {merged_df.shape}")
            return merged_df
        except Exception as e:
            self.logger.error(f"Error merging pipeline data: {str(e)}")
            raise
            
    def _populate_pipeline_template(self, df_template: pd.DataFrame, merged_df: pd.DataFrame) -> pd.DataFrame:
        """Populate template with merged pipeline data"""
        df_temp = df_template.copy()
        
        try:
            df_temp['Type'] = merged_df.get('Opportunity Type', 'Unknown')
            df_temp['Client'] = merged_df.get('Account Legal Name: Account Legal Name', 'Unknown')
            df_temp['Project'] = merged_df.get('Opportunity Name', 'Unknown')
            df_temp['Sold PID/ Opp ID'] = merged_df.get('Sold PID/ Opp ID', 'Unknown')
            df_temp['Opp Probability'] = merged_df.get('Probability', 0)
            df_temp['LOB'] = merged_df.get('LOB', 'Unknown')
            
            # Combine sales price and currency
            sales_price = merged_df.get('Sales Price', 0).astype(str)
            currency = merged_df.get('Sales Price Currency', 'USD')
            df_temp['Project Value'] = sales_price + " " + currency
            
            df_temp['Allocation Start Date'] = merged_df.get('Project Start Date', '')
            df_temp['Allocation End Date'] = merged_df.get('Project End Date', '')
            df_temp['Required from which Month'] = merged_df.get('First Month Recorded', '')
            df_temp['No of resources required'] = merged_df.get('Total hours', 0)
            df_temp['Level'] = merged_df.get('Level', 'Unknown')
            df_temp['Location'] = merged_df.get('Loc', 'Unknown')
            df_temp['Request Date'] = datetime.now().strftime('%m/%d/%Y')
            df_temp['Requested by'] = merged_df.get('Created By: Full Name', 'Unknown')
            df_temp['Sold/Pipeline'] = 'Pipeline'
            
            return df_temp
            
        except Exception as e:
            self.logger.error(f"Error populating pipeline template: {str(e)}")
            raise
            
    def process_assignment_data(self, df_template: pd.DataFrame, df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Process assignment data"""
        self.logger.info("Starting assignment data processing...")
        
        try:
            # Clean assignment data
            df_assignment = self._clean_assignment_data(df_assignment)
            
            # Map employee levels
            df_assignment['Level'] = df_assignment['Level'].apply(self._map_level)
            
            # Extract customer and PM information
            df_assignment = self._extract_customer_pm_info(df_assignment)
            
            # Extract project name
            df_assignment['Project'] = df_assignment['Project Name'].str.split(':', n=1, expand=True)[1].str.strip()
            
            # Group and aggregate data
            grouped_df = self._group_assignment_data(df_assignment)
            
            # Create mappings and populate additional fields
            df_assignment_output = self._populate_assignment_template(df_template, grouped_df, df_assignment)
            
            self.processing_stats['assignment_records_processed'] = len(df_assignment)
            self.logger.info(f"Assignment processing completed. Output shape: {df_assignment_output.shape}")
            return df_assignment_output
            
        except Exception as e:
            self.logger.error(f"Error processing assignment data: {str(e)}")
            raise
            
    def _clean_assignment_data(self, df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Clean assignment data by removing generic employees and renaming columns"""
        # Filter out generic requirement employees
        pattern = r'^A\d{4}[\s_].+'
        original_count = len(df_assignment)
        df_assignment = df_assignment[~(df_assignment['Employee'].str.match(pattern, na=False))]
        filtered_count = len(df_assignment)
        
        self.logger.info(f"Filtered out {filtered_count} generic employees")
        
        # Rename Employee column to Level
        df_assignment.drop(columns=['Level'], inplace=True, errors='ignore')
        df_assignment.rename(columns={'Employee': 'Level'}, inplace=True)
        
        return df_assignment
        
    def _map_level(self, entry: str) -> str:
        """Map employee designation to level"""
        if pd.isna(entry):
            return 'Unknown'
            
        if 'Generic Employee' in str(entry):
            return 'Generic'
            
        entry_lower = str(entry).lower()
        for key, value in self.level_mapping.items():
            if key.lower() in entry_lower:
                return value
                
        return 'Sys Generated'
        
    def _extract_customer_pm_info(self, df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Extract customer and PM information from combined fields"""
        # Extract customer ID and name
        customer_extract = df_assignment['Customer'].str.extract(r'^(CUST\d+)\s+(.*)$')
        df_assignment['Customer ID'] = customer_extract[0]
        df_assignment['Customer name'] = customer_extract[1]
        
        # Extract PM ID and name
        pm_extract = df_assignment['Project Manager'].str.extract(r'^(A\d+)\s+(.*)$')
        df_assignment['PM ID'] = pm_extract[0]
        df_assignment['PM name'] = pm_extract[1]
        
        return df_assignment
        
    def _group_assignment_data(self, df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Group and aggregate assignment data"""
        grouped_df = df_assignment.groupby(['ID', 'Level']).agg({
            'Duration (Decimal)': 'sum'
        }).reset_index()
        
        # Convert duration to resource count
        grouped_df['Duration (Decimal)'] = np.ceil(grouped_df['Duration (Decimal)'] / 525)
        
        return grouped_df
        
    def _populate_assignment_template(self, df_template: pd.DataFrame, grouped_df: pd.DataFrame, 
                                    df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Populate template with assignment data"""
        # Create mappings from original data
        mappings = {
            'client': dict(zip(df_assignment['ID'], df_assignment['Customer name'])),
            'project': dict(zip(df_assignment['ID'], df_assignment['Project'])),
            'lob': dict(zip(df_assignment['ID'], df_assignment['LOB'])),
            'value': dict(zip(df_assignment['ID'], df_assignment['Value'])),
            'start_date': dict(zip(df_assignment['ID'], df_assignment['Start Date'])),
            'end_date': dict(zip(df_assignment['ID'], df_assignment['End Date'])),
            'pm_name': dict(zip(df_assignment['ID'], df_assignment['PM name'])),
            'pm_id': dict(zip(df_assignment['ID'], df_assignment['PM ID'])),
            'location': dict(zip(df_assignment['ID'], df_assignment['Location']))
        }
        
        # Apply mappings
        grouped_df['Client'] = grouped_df['ID'].map(mappings['client'])
        grouped_df['Project'] = grouped_df['ID'].map(mappings['project'])
        grouped_df['LOB'] = grouped_df['ID'].map(mappings['lob'])
        grouped_df['Project Value'] = grouped_df['ID'].map(mappings['value'])
        grouped_df['Allocation Start Date'] = grouped_df['ID'].map(mappings['start_date'])
        grouped_df['Allocation End Date'] = grouped_df['ID'].map(mappings['end_date'])
        grouped_df['Required from which Month'] = pd.to_datetime(
            grouped_df['ID'].map(mappings['start_date']), errors='coerce'
        ).dt.strftime("%b'%y")
        grouped_df['Requested by'] = grouped_df['ID'].map(mappings['pm_name'])
        grouped_df['Location'] = grouped_df['ID'].map(mappings['location'])
        grouped_df['Project Manager'] = grouped_df['ID'].map(mappings['pm_name'])
        grouped_df['PM ID'] = grouped_df['ID'].map(mappings['pm_id'])
        grouped_df['Sold/Pipeline'] = 'Sold'
        grouped_df['Opp Probability'] = 100
        
        # Rename columns to match template
        grouped_df.rename(columns={
            'ID': 'Sold PID/ Opp ID',
            'Duration (Decimal)': 'No of resources required'
        }, inplace=True)
        
        # Reorder columns to match template
        df_output = grouped_df.reindex(columns=df_template.columns, fill_value='')
        
        return df_output
        
    def combine_and_export(self, df_pipeline: pd.DataFrame, df_assignment: pd.DataFrame) -> pd.DataFrame:
        """Combine pipeline and assignment data and export to CSV"""
        self.logger.info("Combining pipeline and assignment data...")
        
        try:
            # Combine dataframes
            df_combined = pd.concat([df_pipeline, df_assignment], ignore_index=True)
            
            # Additional data cleaning and validation
            df_combined = self._final_data_cleanup(df_combined)
            
            # Export to CSV
            output_path = Path(self.config_paths['output_dir']) / 'demand_pipeline.csv'
            df_combined.to_csv(output_path, index=False)
            
            self.processing_stats['total_records_output'] = len(df_combined)
            self.logger.info(f"Successfully exported {len(df_combined)} records to {output_path}")
            
            return df_combined
            
        except Exception as e:
            self.logger.error(f"Error combining and exporting data: {str(e)}")
            raise
            
    def _final_data_cleanup(self, df: pd.DataFrame) -> pd.DataFrame:
        """Perform final data cleanup and validation"""
        # Handle missing values
        df = df.fillna('')
        
        # Validate numeric columns
        numeric_columns = ['No of resources required', 'Opp Probability']
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col]).fillna(0)
                
        # Validate and format dates
        date_columns = ['Allocation Start Date', 'Allocation End Date']
        for col in date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime('%m/%d/%Y')
                df[col] = df[col].fillna('')
                
        return df
        
    def run_pipeline(self) -> bool:
        """Run the complete demand processing pipeline"""
        self.logger.info("Starting demand processing pipeline...")
        
        try:
            # Step 1: Validate configuration
            if not self.validate_config():
                self.logger.error("Configuration validation failed")
                return False
                
            # Step 2: Load data
            df_template, df_pipeline, df_assignment = self.load_data()
            
            # Step 3: Process pipeline data
            df_pipeline_processed = self.process_pipeline_data(df_template, df_pipeline)
            
            # Step 4: Process assignment data
            df_assignment_processed = self.process_assignment_data(df_template, df_assignment)
            
            # Step 5: Combine and export
            df_final = self.combine_and_export(df_pipeline_processed, df_assignment_processed)
            
            # Step 6: Print final statistics
            self.print_processing_summary()
            
            self.logger.info("Demand processing pipeline completed successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Pipeline execution failed: {str(e)}")
            return False
            
    def print_processing_summary(self):
        """Print processing summary statistics"""
        self.logger.info("=== PROCESSING SUMMARY ===")
        self.logger.info(f"Pipeline files processed: {self.processing_stats['pipeline_files_processed']}")
        self.logger.info(f"Pipeline files failed: {self.processing_stats['pipeline_files_failed']}")
        self.logger.info(f"Assignment records processed: {self.processing_stats['assignment_records_processed']}")
        self.logger.info(f"Total records in output: {self.processing_stats['total_records_output']}")
        self.logger.info("=========================")


def main():
    """Main execution function"""
    # Configuration - update these paths according to your setup
    config_paths = {
        'demand_columns_csv': r'data/demand_columns.csv',
        'pipeline_csv': r'data/Pipeline.csv',
        'assignment_csv': r'data/assignment.csv',
        'pricing_sheets_dir': r'data/pricing sheets',
        'output_dir': r'output'
    }
    
    # Create output directory if it doesn't exist
    Path(config_paths['output_dir']).mkdir(parents=True, exist_ok=True)
    
    # Initialize and run processor
    processor = DemandProcessor(config_paths, log_level='INFO')
    
    success = processor.run_pipeline()
    
    if success:
        print("✅ Pipeline completed successfully!")
        return 0
    else:
        print("❌ Pipeline failed. Check logs for details.")
        return 1


if __name__ == "__main__":
    exit(main())