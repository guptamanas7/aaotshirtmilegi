"""
Configuration file for WFM Pipeline
Contains all paths, constants, and configuration parameters
"""

import os
from pathlib import Path

# Base paths
# BASE_DIR = Path(r"C:\Users\A8611\Axtria\Manas Gupta - WFM\LOB Tracker")
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = BASE_DIR / "cache"
OUTPUT_DIR = BASE_DIR / "output"

# Monthly timesheet folder path
MONTHLY_TIMESHEET_DIR = DATA_DIR / "Timesheet_monthly"

# Input file paths
INPUT_FILES = {
    'roster': DATA_DIR / "roster.csv",
    'template': DATA_DIR / "template.csv",
    'employee': DATA_DIR / "employee.csv",
    'skills': DATA_DIR / "skills.csv",
    'attainment': DATA_DIR / "attainment.csv",
    'timesheet': DATA_DIR / "timesheet.csv",  # This will be the combined timesheet
    'assignment': DATA_DIR / "assignment.csv",
    'ytd_missing': DATA_DIR / "ytd_missing.csv",
    'exclusion': DATA_DIR / "exclusionlist.csv",
}

# Output file paths
OUTPUT_FILES = {
    'summary': CACHE_DIR / "summary.csv",
    'final_report': OUTPUT_DIR / "LOBTracker.csv",
    'combined_timesheet': DATA_DIR / "timesheet.csv"  # Combined timesheet output path
}

# Timesheet combination settings
TIMESHEET_SETTINGS = {
    'monthly_folder': MONTHLY_TIMESHEET_DIR,
    'combined_output': OUTPUT_FILES['combined_timesheet'],
    'file_prefix': 'TS_',
    'force_recreate': False  # Set to True to always recreate combined file
}

# Filter criteria
FILTERS = {
    'category_name': "COGS",
    'sub_category_name': "Horizontal",
    'max_level': 9,
    'regular_temporary': "Regular"  # Optional filter
}

# Bench PIDs
BENCH_PIDS = {
    "AXTR00327", "AXTR00726", "AXTR00423", "AXTR00342", "AXTR05716",
    "AXTR05504", "AXTR06204", "AXTR07663", "AXTR06205", "AXTR03757",
    "AXTR05055", "AXTR07306", "AXTR05056", "AXTR07307", "AXTR04180",
    "AXTR07803"
}

# Constants
CONSTANTS = {
    'high_bench_threshold': 30,  # Hours per week
    'standard_monthly_hours': 160,
    'billing_categories': {
        'bins': [-1, 25, 50, 75, 1000],
        'labels': ["Less than 25%", "25% to 50%", "50% to 75%", "More than 75%"]
    },
    'exclusion_leave_types': ["Maternity Leave", "Sabbatical Leave", "Long LWP"]
}

# Column mappings
COLUMN_MAPPINGS = {
    'roster_to_template': {
        'Employee ID': 'User/Employee ID',
        'Name': 'Name',  # Will be constructed
        'Level': 'Level  Name',
        'Hire Date': 'Employment Details Transfer/ Conversion Date',
        'Country': 'Geozone  Name',
        'LOB': 'Group Name',
        'RO': 'Reporting Org',
        'Hiring source': 'Hiring source'
    },
    'name_columns': ['First Name', 'Middle Name', 'Last Name'],
    'employee_mappings': {
        'Location': 'Location',
        'Group Lead': 'Group Lead',
        'Supervisor': 'Supervisor'
    },
    'skills_mappings': {
        'Basic': '1',
        'Tertiary': '2',
        'Secondary': '3',
        'Primary': '4'
    }
}

PRESERVE_COLUMNS = [
    'Available Date', 'SPOC', 'Project end date', 'Resource Block date', 
    'Proposed Account', 'New Project Start date', 'Remarks', 'Old Comments'
]

# Create directories if they don't exist
for directory in [DATA_DIR, CACHE_DIR, OUTPUT_DIR, MONTHLY_TIMESHEET_DIR]:
    directory.mkdir(parents=True, exist_ok=True)