# WFM Pipeline - Production Structure

A production-ready workforce management pipeline that processes employee data from multiple sources to generate comprehensive LOB tracking reports.

## Directory Structure

```
wfm_pipeline/
├── config.py                 # Configuration and constants
├── main.py                   # Main execution orchestrator
├── run_pipeline.py           # Example runner with reporting
├── requirements.txt          # Python dependencies
├── README.md                 # This file
├── utils/                    # Utility modules
│   ├── __init__.py           # Package initialization
│   ├── io_helpers.py         # I/O operations and data loading
│   ├── preprocessors.py      # Data preprocessing and filtering
│   ├── mappers.py            # Data mapping between sources
│   ├── calculators.py        # Complex calculations and metrics
│   └── aggregator.py         # Final aggregation and formatting
├── data/                     # Input data directory
|   ├──Timesheet_monthly
|   |  ├──jan_2025.csv
|   |  ├──feb_2025.csv
│   ├── roster.csv
│   ├── template.csv
│   ├── employee.csv
│   ├── skills.csv
│   ├── attainment.csv
│   ├── assignment.csv
│   ├── ytd_missing.csv
│   └── exclusionlist.csv
├── cache/                    # Temporary cache files
│   └── summary.csv
└── output/                   # Final output directory
    └── LOBTracker.csv
```

## Features

### Data Processing
- **Multi-source Integration**: Combines data from 7 different CSV sources
- **Incremental Processing**: Maintains cache for efficient re-runs
- **Data Validation**: Validates input files before processing
- **Error Handling**: Comprehensive error handling with logging

### Metrics Calculated
- **Utilization Metrics**: Current, next, and next-to-next month assignments
- **Bench Analytics**: YTD high bench count and current bench percentage
- **Billing Analysis**: Billable vs non-billable hours categorization
- **Skills Mapping**: Multi-level skill categorization
- **Project Tracking**: Current project assignments

### Production Features
- **Modular Design**: Separated concerns into focused modules
- **Configurable**: All paths and constants in configuration file
- **Logging**: Comprehensive logging for monitoring and debugging
- **Summary Statistics**: Automated report statistics generation

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Update paths in `config.py` to match your environment:
```python
BASE_DIR = Path(r"C:\Your\Path\To\WFM\Pipeline")
```

3. Ensure all input CSV files are present in the `data/` directory

## Usage

### Basic Execution
```python
from main import main

success = main()
if success:
    print("Pipeline completed successfully")
else:
    print("Pipeline failed")
```

### Enhanced Execution with Reporting
```bash
python run_pipeline.py
```

### Programmatic Usage
```python
from utils import *
from config import INPUT_FILES

# Load specific data
df_roster = load_data(INPUT_FILES['roster'])

# Preprocess data
df_processed = preprocess_roster(df_roster, FILTERS)

# Calculate specific metrics
df_with_bench = calculate_bench_metrics(df_template, df_timesheet)
```

## Configuration

### Key Configuration Options

- **File Paths**: Update `INPUT_FILES` and `OUTPUT_FILES` in `config.py`
- **Filters**: Modify `FILTERS` dictionary for different filtering criteria
- **Bench PIDs**: Update `BENCH_PIDS` set for bench project identification
- **Constants**: Adjust thresholds and standards in `CONSTANTS`

### Example Configuration
```python
FILTERS = {
    'category_name': "COGS",
    'sub_category_name': "Horizontal",
    'max_level': 9
}

CONSTANTS = {
    'high_bench_threshold': 30,  # Hours per week
    'standard_monthly_hours': 160
}
```

## Input Data Requirements

### Required CSV Files
1. **roster.csv**: Employee roster with basic information
2. **template.csv**: Output template structure
3. **employee.csv**: Additional employee details (location, supervisor)
4. **skills.csv**: Employee skill levels
5. **attainment.csv**: YTD billing attainment data
6. **timesheet.csv**: Time tracking data
7. **assignment.csv**: Project assignment data

### Key Columns Expected
- **roster.csv**: Category Name, Sub Category Name, User/Employee ID, First Name, Last Name, etc.
- **timesheet.csv**: Date, Employee, PID, Duration (Decimal), Billability
- **assignment.csv**: Date, Employee, Duration (Decimal), Project Name

## Output

### Final Report Columns
- Employee information (ID, Name, Level, Location, etc.)
- Skills data (Basic, Tertiary, Secondary, Primary)
- Utilization metrics (Current Month, Next Month, %)
- Bench analytics (Bench %, YTD HI Bench Count)
- Billing categorization (Billed Category)
- Project assignments (Project)

### Summary Statistics
- Total employees processed
- Average utilization percentage
- Bench statistics
- Billing category distribution

## Logging

The pipeline generates comprehensive logs including:
- Step-by-step execution progress
- Data loading and processing statistics
- Error messages and stack traces
- Performance metrics

Logs are written to both console and `wfm_pipeline.log` file.

## Error Handling

- **File Validation**: Checks for missing input files
- **Data Validation**: Handles missing or malformed data
- **Type Conversion**: Safe numeric conversions with error handling
- **Graceful Failures**: Continues processing when possible, logs errors

## Performance Considerations

- **Incremental Processing**: Bench calculations use cached summaries
- **Efficient Joins**: Uses dictionary mappings for fast lookups
- **Memory Management**: Processes data in chunks where appropriate
- **Pandas Optimization**: Uses vectorized operations for calculations

## Maintenance

### Adding New Metrics
1. Add calculation function to `calculators.py`
2. Update `main.py` to call new function
3. Add new columns to `aggregator.py` if needed
4. Update configuration if new constants required

### Modifying Filters
1. Update `FILTERS` in `config.py`
2. Modify preprocessing functions in `preprocessors.py`
3. Test with sample data

### Changing Output Format
1. Modify `aggregate_final_report()` in `aggregator.py`
2. Update `_ensure_required_columns()` for new column requirements
3. Update documentation