"""
Example script to run the WFM Pipeline
This script demonstrates how to execute the pipeline and handle results
"""

import sys
import logging
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from main import main
from utils.aggregator import calculate_summary_statistics
from utils.io_helpers import load_data
from config import OUTPUT_FILES

def run_pipeline_with_reporting():
    """
    Run the pipeline and generate summary report
    """
    print("="*60)
    print("WFM PIPELINE EXECUTION")
    print("="*60)
    
    # Run the main pipeline
    success = main()
    
    if success:
        print("\n" + "="*60)
        print("PIPELINE SUMMARY")
        print("="*60)
        
        try:
            # Load the final report
            df_final = load_data(OUTPUT_FILES['final_report'])
            
            # Calculate summary statistics
            stats = calculate_summary_statistics(df_final)
            
            # Print summary
            print(f"Total Employees Processed: {stats.get('total_employees', 'N/A')}")
            print(f"Employees with Projects: {stats.get('employees_with_projects', 'N/A')}")
            print(f"Average Utilization: {stats.get('avg_utilization', 0):.2f}%")
            print(f"Average Bench Percentage: {stats.get('avg_bench_percentage', 0):.2f}%")
            print(f"High Bench Employees (>50%): {stats.get('high_bench_employees', 'N/A')}")
            
            # Print billing distribution
            billing_dist = stats.get('billing_distribution', {})
            if billing_dist:
                print("\nBilling Category Distribution:")
                for category, count in billing_dist.items():
                    print(f"  {category}: {count}")
            
            print(f"\nFinal report saved to: {OUTPUT_FILES['final_report']}")
            
        except Exception as e:
            print(f"Error generating summary: {str(e)}")
    
    else:
        print("Pipeline execution failed. Check logs for details.")
    
    print("="*60)
    return success

if __name__ == "__main__":
    success = run_pipeline_with_reporting()
    sys.exit(0 if success else 1)